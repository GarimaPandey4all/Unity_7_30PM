﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberGuess : MonoBehaviour {

	int max;
	int min;
	int guess;

	// Use this for initialization
	void Start () {
		StartGame();
	}
	void StartGame()
    {
		//int max = 1000;
		//int min = 1;
		//int guess = 500;

		max = 1000;
		min = 1;
		guess = 500;

		Debug.Log("Welcome to Number Guess");
		Debug.Log("Pick a number, don't tell me what it is...");
		//Debug.Log("The highest number you can pick is 1000");
		//Debug.Log("The Lowest number you can pick is 1");
		Debug.Log("The highest number you can pick is: " + max);
		Debug.Log("The Lowest number you can pick is: " + min);
		Debug.Log("Tell me if your number is higher or lower than: " + guess);
		Debug.Log("Push Up = Higher, Push Down = Lower, Push Enter = Correct");
		max = max + 1;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.UpArrow))
        {
			//Debug.Log("Up Arrow key was pressed.");
			//Debug.Log(guess);
			//guess = (max + min) / 2;
			//Debug.Log("Is it higher or lower than..." + guess);
			min = guess;
			NextGuess();
		}

		else if (Input.GetKeyDown(KeyCode.DownArrow))
		{
			//Debug.Log("Down Arrow key was pressed.");
			//guess = (max + min) / 2;
			//Debug.Log("Is it higher or lower than..." + guess);
			//Debug.Log(guess);
			max = guess;
			NextGuess();
		}

		else if (Input.GetKeyDown(KeyCode.Return))
		{
			Debug.Log("I'm a genious!");
			StartGame();
		}
	}

	void NextGuess()
	{
		guess = (max + min) / 2;
		Debug.Log("Is it higher or lower than..." + guess);
	}
}
